import * as React from "react";
import { createRoot } from "react-dom/client";
import "../../src/styles.css";
import "./demo.css";
import App from "./App";

const element = document.getElementById("root");
if (!element) throw new Error("Missing #root element");

createRoot(element).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
