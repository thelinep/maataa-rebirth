import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath, URL } from "node:url";

const demoRoot = fileURLToPath(new URL(".", import.meta.url));
const srcRoot = fileURLToPath(new URL("../../src", import.meta.url));

function maataaManualChunks(id) {
  const normalized = id.replaceAll("\\", "/");
  if (normalized.includes("/node_modules/react/") || normalized.includes("/node_modules/react-dom/")) return "vendor-react";
  if (normalized.includes("/node_modules/@reduxjs/") || normalized.includes("/node_modules/react-redux/")) return "vendor-state";
  if (normalized.includes("/src/registries/") || normalized.includes("/src/registry-")) return "maataa-registries";
  if (normalized.includes("/src/static-data/") || normalized.includes("/src/demo/")) return "maataa-demo-data";
  if (normalized.includes("/src/redux/")) return "maataa-redux";
  if (normalized.includes("/src/composer/")) return "maataa-composer";
  if (normalized.includes("/src/runtime/")) return "maataa-runtime";
  if (normalized.includes("/src/tools/") || normalized.includes("/src/tool-")) return "maataa-tools";
  if (normalized.includes("/src/generators/") || normalized.includes("/src/generator-")) return "maataa-generators";
  if (normalized.includes("/src/ai-spaces/") || normalized.includes("/src/ai-space-")) return "maataa-ai-spaces";
  if (normalized.includes("/src/devices/") || normalized.includes("/src/device-")) return "maataa-devices";
  if (normalized.includes("/src/layouts/") || normalized.includes("/src/layout-")) return "maataa-layouts";
  if (normalized.includes("/src/pages/") || normalized.includes("/src/page-")) return "maataa-pages";
  if (normalized.includes("/src/workspaces/") || normalized.includes("/src/workspace-")) return "maataa-workspaces";
}

export default defineConfig({
  root: demoRoot,
  plugins: [react()],
  resolve: {
    alias: [
      { find: /^@maataa\/ui$/, replacement: `${srcRoot}/index.ts` },
      { find: /^@maataa\/ui\/(.+)$/, replacement: `${srcRoot}/$1` },
    ],
  },
  server: { host: "127.0.0.1", port: 4173, strictPort: true },
  preview: { host: "127.0.0.1", port: 4173, strictPort: true },
  build: {
    outDir: fileURLToPath(new URL("../../demo-dist", import.meta.url)),
    emptyOutDir: true,
    chunkSizeWarningLimit: 900,
    rollupOptions: { output: { manualChunks: maataaManualChunks } },
  },
});
